Hello!

This is my text based game using Python

Make sure to run this game in text editor shell!

To go throught the game you will need to use action words such as "go" "take"
For example to add something to your inventory "take shovel"
		to go north say "go north"


Enjoy the game!!!
					