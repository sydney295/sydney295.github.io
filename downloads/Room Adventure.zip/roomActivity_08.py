######################################################
# the blueprint for a room
class Room:
    # the constructor
    def __init__(self, name):
        # rooms have a name, exits (e.g., south), exit
        # locations (e.g., to the south is room n), items
        # (e.g., table), item descriptions (for each item),
        # and grabbables (things that can be taken into
        # inventory)
        self.name = name
        self.exits = []
        self.exitLocations = []
        self.items = []
        self.itemDescriptions = []
        self.grabbables = []
    # getters and setters for the instance variables
    @property

    def name(self):
        return self._name
    @name.setter
    def name(self, value):
        self._name = value
    @property
    def exits(self):
        return self._exits
    @exits.setter
    def exits(self, value):
        self._exits = value
    @property
    def exitLocations(self):
        return self._exitLocations
    @exitLocations.setter
    def exitLocations(self, value):
        self._exitLocations = value
    @property
    def items(self):
        return self._items
    @items.setter
    def items(self, value):
        self._items = value
    @property
    def itemDescriptions(self):
        return self._itemDescriptions
    @itemDescriptions.setter
    def itemDescriptions(self, value):
        self._itemDescriptions = value
    @property
    def grabbables(self):
        return self._grabbables
    @grabbables.setter
    def grabbables(self, value):
        self._grabbables = value

    # adds an exit to the room
    # the exit is a string (e.g., north)
    # the room is an instance of a room
    def addExit(self, exit, room):
        # append the exit and room to the appropriate lists
        self._exits.append(exit)
        self._exitLocations.append(room)
    
    # adds an item to the room
    # the item is a string (e.g., table)
    # the desc is a string that describes the item (e.g., it is
    # made of wood)
    def addItem(self, item, desc):
        # append the item and exit to the appropriate lists
        self._items.append(item)
        self._itemDescriptions.append(desc)
    # adds a grabbable item to the room
    # the item is a string (e.g., key)
    def addGrabbable(self, item):
        # append the item to the list
        self._grabbables.append(item)
    # removes a grabbable item from the room
    # the item is a string (e.g., key)
    def delGrabbable(self, item):
        # remove the item from the list
        self._grabbables.remove(item)
    # returns a string description of the room
    def __str__(self):
    # first, the room name
        s = "You are in {}.\n".format(self.name)
        # next, the items in the room
        s += "You see: "
        for item in self.items:
            s += item + " "
        s += "\n"
        # next, the exits from the room
        s += "Exits: "
        for exit in self.exits:
            s += exit + " "
        

        return s

#create rooms
    
    
 ######################################################
# creates the rooms
def createRooms():
    # r1 through r4 are the four rooms in the mansion
    # currentRoom is the room the player is currently in (which
    # can be one of r1 through r4)
    # since it needs to be changed in the main part of the
    # program, it must be global
    global currentRoom
    # create the rooms and give them meaningful names
    r1 = Room("The Graveyard")
    r2 = Room("Inside grave")
    r3 = Room("Morgue ,You hear its claws scraping against the walls. FIND A WEAPON")
    r4 = Room("Playground, explore a bit")
    r5 = Room("Church, you are safe in here")
    r6 = Room("Morgue Table")
    r7 = Room("File")
    r8 = Room("Up the Hill")
    r9 = Room("Read journal")
    r10 = Room("Locked Room")
    r11 = Room("Outside church")
    r12 = Room("NICE SHOT")
    r13 = Room("Police Station")
  

    # add exits to room 1 the graveyard
    r1.addExit("inside_grave", r2)
    r1.addExit("south", r3)
    r1.addExit("up_hill", r8)
    # add grabbables to room 1
    r1.addGrabbable("shovel")
    # add items to room 1
    r1.addItem("Your grandfather's headstone", "It is made of cobblestone and no one is sitting on it.")
    r1.addItem(", A shovel", "It is made of oak and metal. A golden key rests on it.")

    # add exits to room 2  inside grave
    r2.addExit("up", r1)
    #r2.addExit("south", r4)
    #r2.addGrabbable("journal")
    r2.addGrabbable("bullet")
    # add items to room 2
    #r2.addItem("journal,", "find somewhere safe to read it!")
    r2.addItem("A single bullet", "It is full of ashes.")

    # add exits to room 3  morgue
    r3.addExit("north", r1)
    r3.addExit("east", r4)
    r3.addExit("morgue_table", r6)
    # add grabbables to room 3
    r3.addGrabbable("book")
    # add items to room 3
    r3.addItem("a table", "take a closer look ")
    r3.addItem("picture", "the scraping is getting closer...and louder")
    r3.addItem("corpse", "Its hearts is eaten out, as well as the liver")
    
    #r3.addItem("desk", "The statue is resting on it. So is a book.")
    
    # add exits to room 4  playground
    r4.addExit("north", r2)
    r4.addExit("west", r3)
    r4.addExit("south", r5) # DEATH!
    # add grabbables to room 4
    r4.addGrabbable("keys")
    r4.addGrabbable("journalpage")

    # add items to room 4
    r4.addItem("branches", "The branches are broken. You hear and hear a growling coming\nfrom behind you what is making that sound.")
    r4.addItem("swing", "swinging slowly, Who was just here?")
    r4.addItem("keys", "What do these open")
    r4.addItem("journalpage", "find somewhere safe to read it!")
    
    #ROOM 5
    
    #add exits to room 5   church
    r5.addItem("Pulpit,", "no communion wine sadly")
    r5.addItem("backroom,", "It's locked, what's in there? need a key probably")
    r5.addExit("north", r4)
    r5.addExit("backroom", r10)
    #add items to room 6
    r6.addItem("pen,", "no ink")
    r6.addItem("File with pictures sticking out", "What are the pictures of.")
    
    #add exits to room 6  morgue table
    r6.addExit("up", r3)
    r6.addExit("file", r7)
    r6.addExit("read_journal", r9)
    #add grabbables to room 6
    r6.addGrabbable("file")
    #add items to room 7 File
    
    r7.addItem("file: Half eaten corpse next to a dug up grave up the hill from the your grandfather's grave\n\t Closeups: Next to the body is a humanoid footprint\n\t\t   On one side of the body\n\t\t   Faint red glowing eyes in the background","What are the pictures of.")
    
    #add exits to room 7
    
    r7.addExit("up", None)
    
    # add items to room 8  up the hill
    r8.addItem("corpse,", "smells horrible")
    r8.addItem("footprint,", "also smells horrible")
    r8.addItem("No sign of those glowing eyes,", "missed your chance")
    #add exit to room 8 
    r8.addExit("down_hill", r1)
   
    #add items to room 9 read journal
    r9.addItem("Pastor James journal:\n\t Something unholy roams this town, it eats the living and the dead\n\t DO NOT let your gaurd down. For some reason it can't enter the church.\n\t It hunts like an animal ", "smells horrible")
    #add exit to room 9
    r9.addExit("up", None)
    
    #room 10  Locked room in church

    r10.addItem("body", "Pastor Homer has a gunshot wound to his head")
    r10.addItem("gun", "one bullet left")
    r10.addItem("note", "There's no way out. Hopefully god has mercy on me, I couldn't take it.")
    
    #add grabbables
    
    r10.addGrabbable("gun")
    
    #add exits
    
    r10.addExit("church", r5)
    r10.addExit("back_exit",r11 )
    
    #Room 11 outside church
    
    r11.addItem("the Darkness is disorienting, you hear a sound but can't tell where its coming from", "you can't see anything")
    r11.addItem("choose wisely in what direction to shoot in", "you can't see anything")
    
    r11.addExit("left",None )
    r11.addExit("right",None )
    r11.addExit("front",None )
    r11.addExit("back",r12 )
    
    #room 12
    r12.addItem("You lived for now, play again and see waht else you can find", "you can't see anything")
    
    r12.addExit("graveyard", r1)
    
    #room 13   police station
    
    
    r13 = Room("You lived...for now.")
    
    
    # set room 1 as the current room at the beginning
    # of the game
    currentRoom = r1   


######################################################
# START THE GAME!!!
inventory = [] # nothing in inventory...yet
createRooms() # add the rooms to the game
# play forever (well, at least until the player dies or asks to
# quit)

while (True):
    
    # set the status so the player has situational awareness
    # the status has room and inventory information
    status = "{}\nYou are carrying: {}\n".format(currentRoom, inventory)

    # if the current room is None, then the player is dead
    # this only happens if the player goes south when in room 4
    if (currentRoom == None):
        status = "You are dead.\n\t you let your guard down(Find somewhere safe to read things)\n\t You shot the wrong way"
    # display the status
    print("=========================================")
    print(status)
    
    # if the current room is None (and the player is dead),
    # exit the game
    if (currentRoom == None):
        death()
        break

    # prompt for player input
    # the game supports a simple language of <verb> <noun>
    # valid verbs are go, look, and take
    # valid nouns depend on the verb
    action = input("What to do? ")

    # set the user's input to lowercase to make it easier to
    # compare the verb and noun to known values
    action = action.lower()

    # exit the game if the player wants to leave (supports
    # quit, exit, and bye)
    if (action == "quit" or action == "exit" or action == "bye"):
        break

    # set a default response
    response = "I don't understand. Try verb noun. Valid verbs are go, look, and take"
    # split the user input into words (words are separated by
    # spaces)
    words = action.split()
    # the game only understands two word inputs
    if (len(words) == 2):
        # isolate the verb and noun
        verb = words[0]
        noun = words[1]
        
        # the verb is: go
        if (verb == "go"):
            # set a default response
            response = "Invalid exit."
            
            # check for valid exits in the current room
            for i in range(len(currentRoom.exits)):
                # a valid exit is found
                if (noun == currentRoom.exits[i]):
                    if (currentRoom.name == "The Graveyard") and ("shovel" not in inventory) and (noun == "inside_grave"):
                           
                            response = "You need a shovel to dig dipshit."
                    
                    elif (currentRoom.name == "Morgue Table") and ("file" not in inventory) and (noun == "file"):
                        
                        response = "No file available to read."
                        
                    elif (currentRoom.name == "Locked Room") and ("gun" not in inventory) and (noun == "back_exit"):
                    
                        response = "you need a weapon to face the monster, find one first"
                        
                        
                    else:
                        currentRoom = currentRoom.exitLocations[i]
                        response = "Room changed"
                        
            
                   
                        
                            
                        
                        
                    #eli
                        
                        
                    # if current room's name is trouble room and trying to go name direction
                        #if dont have item say tough shit
                        #else change the room
                    
                    # else change the current room to the one
                    # that is associated with the specified
                    # exit
                    #currentRoom = currentRoom.exitLocations[i]
                
                    # set the response (success)
                    #response = "Room changed."
                    # no need to check any more exits
                    break
        # the verb is: look
        elif (verb == "look"):
            # set a default response
            response = "I don't see that item."

            # check for valid items in the current room
            for i in range(len(currentRoom.items)):
                # a valid item is found
                if (noun == currentRoom.items[i]):
                    # set the response to the item's
                    # description
                    response = currentRoom.itemDescriptions[i]
                    # no need to check any more items

                    break
        # the verb is: take
        elif (verb == "take"):
            # set a default response
            response = "I don't see that item."
            # check for valid grabbable items in the current
            # room

            for grabbable in currentRoom.grabbables:
                # a valid grabbable item is found
                if (noun == grabbable):
                    # add the grabbable item to the player's
                    # inventory
                    inventory.append(grabbable)
                    # remove the grabbable item from the
                    # room
                    currentRoom.delGrabbable(grabbable)
                    # set the response (success)
                    response = "Item grabbed."
                    # no need to check any more grabbable
                    # items
                    break
        # display the response
        print("\n{}".format(response))